PORTOFOLIO WEB MARIP MAULANA
=============================

File utama: index.html
Website statis, responsif untuk HP dan komputer, tidak membutuhkan framework atau biaya hosting.

CARA PUBLIKASI GRATIS MELALUI GITHUB PAGES
1. Buka https://github.com/ dan buat akun / masuk.
2. Buat repository baru bernama: NAMA-USERNAME.github.io
   Ganti NAMA-USERNAME dengan username GitHub kamu. Contoh: maripmaulana.github.io
3. Pilih Public (diperlukan untuk GitHub Free), lalu buat repository.
4. Di repository, pilih Add file > Upload files.
5. Unggah index.html dari folder ini, lalu tekan Commit changes.
6. Buka Settings > Pages.
7. Pada Build and deployment, pilih Source: Deploy from a branch.
8. Pilih Branch: main dan folder /(root), lalu tekan Save.
9. Tunggu beberapa menit. Website akan tersedia di:
   https://NAMA-USERNAME.github.io
   Ganti NAMA-USERNAME dengan username GitHub yang kamu pakai.
10. Buka URL tersebut di HP untuk memeriksa tampilan.

Panduan resmi:
https://docs.github.com/en/pages/quickstart

PENTING SEBELUM DIPUBLIKASIKAN
- Situs ini bersifat publik; nomor WhatsApp dan email akan terlihat oleh siapa pun.
- Periksa kembali semua detail dan pastikan daftar keahlian benar-benar sesuai pengalaman.
- Tambahkan riwayat kerja, tanggal proyek, sertifikat, dan foto pekerjaan asli jika ada.
- Jangan menambahkan informasi rahasia pelanggan, password, atau detail jaringan internal.
- Belum ada URL publik sampai kamu menyelesaikan langkah publikasi di atas.
